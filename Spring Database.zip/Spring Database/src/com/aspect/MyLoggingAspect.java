package com.aspect;

import org.apache.log4j.Logger;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;

@Aspect
public class MyLoggingAspect {
	
	Logger logger=Logger.getLogger(getClass());
	
	@Before(value = "execution(* com.dao.EmployeeDAO.deleteEmployeeById(..))")
	public void beforeAdvice(JoinPoint joinPoint) {
		logger.info("executing method---->"+
	    joinPoint.getSignature());
	}

}
