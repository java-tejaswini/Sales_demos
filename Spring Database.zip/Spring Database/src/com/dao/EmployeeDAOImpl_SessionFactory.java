package com.dao;

import java.util.List;

import javax.persistence.TypedQuery;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.pojo.Employee;

@Repository(value = "dao_session")
public class EmployeeDAOImpl_SessionFactory implements EmployeeDAO {

	@Autowired
	SessionFactory sessionFactory;

	@Override
	public int addEmployee(Employee employee) {
		// TODO Auto-generated method stub

		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		try {
			session.save(employee);
			transaction.commit();
			return 1;
		} catch (DataAccessException e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
		}
		return 0;
	}

	@Override
	public boolean updateEmployeeSalary(int empId, int salary) {
		// TODO Auto-generated method stub

		Employee employee = findEmployeeById(empId);
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		try {
			if (employee != null) {
				employee.setSalary(salary);
				session.update(employee);
				transaction.commit();
				return true;
			}
		} catch (DataAccessException e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
		}
		return false;
	}

	@Override
	public Employee findEmployeeById(int empId) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		try {
			Employee employee = session.find(Employee.class, empId);
			transaction.commit();
			return employee;
		} catch (DataAccessException e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
		}
		return null;
	}

//HQL= Hibernate Query Language
	@Override
	public List<Employee> findAllEmployees() {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		// Transaction transaction = session.beginTransaction();
		Query<Employee> query = session.createQuery("from com.pojo.Employee");
		List<Employee> list = query.list();

		return list;
	}

	@Override
	public List<Employee> findAllEmployeesBySalary(int salary) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.openSession();
		// Transaction transaction = session.beginTransaction();
		TypedQuery<Employee> query =
				session.createQuery("from com.pojo.Employee where salary=:sal");
		query.setParameter("sal", salary);
		List<Employee> list = query.getResultList();

		return list;
	}

	@Override
	public int deleteEmployeeById(int empId) {
		// TODO Auto-generated method stub
		return 0;
	}

}
