package com.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.pojo.Employee;

public class EmployeeRowMapper implements RowMapper<Employee> {

	@Override
	public Employee mapRow(ResultSet resultSet, int i) throws SQLException {
		// TODO Auto-generated method stub
		Employee employee = new Employee();
		int empId = resultSet.getInt(1);
		employee.setEmpId(empId);
		employee.setEmpName(resultSet.getString(2));
		employee.setSalary(resultSet.getInt(3));
		return employee;
	}

}
