package com.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;




import com.pojo.Employee;

@Repository(value = "dao_template")
public class EmployeeDAO_template implements EmployeeDAO {
	@Autowired
	JdbcTemplate jdbcTemplate;

//	@Autowired
//	public EmployeeDAO_template(JdbcTemplate jdbcTemplate) {
//		// TODO Auto-generated constructor stub
//		this.jdbcTemplate = jdbcTemplate;
//	}

//	@Autowired
//	public EmployeeDAO_template(DataSource dataSource) {
//		// TODO Auto-generated constructor stub
//		this.jdbcTemplate = new JdbcTemplate(dataSource);
//	}

	@Override
	public int addEmployee(Employee employee) {
		// TODO Auto-generated method stub
		int rows_added = 0;
		String ADD = "insert into employee values(?,?,?)";
		rows_added = jdbcTemplate.update(ADD, employee.getEmpId(), employee.getEmpName(), employee.getSalary());

		return rows_added;
	}

	@Override
	public boolean updateEmployeeSalary(int empId, int salary) {
		// TODO Auto-generated method stub
		boolean isUpdated = false;
		String UPDTAE_SALARY = "update employee set salary=? where empid=?";

		int rows_updated = jdbcTemplate.update(UPDTAE_SALARY, salary, empId);
		if (rows_updated > 0) {
			isUpdated = true;
		}
		return isUpdated;
	}

	@Override
	public int deleteEmployeeById(int empId) {
		// TODO Auto-generated method stub
		int deleted = 0;
		String DELETE_BY_ID = "delete from employee where empid=?";
		deleted = jdbcTemplate.update(DELETE_BY_ID, empId);
		return deleted;
	}

	@Override
	public Employee findEmployeeById(int empId) {
		// TODO Auto-generated method stub
		Employee employee = null;
		String FIND_BY_ID = "select * from employee where empid=?";
//	  employee=	jdbcTemplate.queryForObject(FIND_BY_ID, new Object[] {empId},new EmployeeRowMapper());
		employee = jdbcTemplate.queryForObject(FIND_BY_ID, new EmployeeRowMapper(), new Object[] { empId });
		return employee;
	}

	@Override
	public List<Employee> findAllEmployees() {
		// TODO Auto-generated method stub
		List<Employee> employees = new ArrayList<>();
		String FIND_ALL = "select * from employee";
		employees = jdbcTemplate.query(FIND_ALL, new RowMapper<Employee>() {

			@Override
			public Employee mapRow(ResultSet resultSet, int i) throws SQLException {
				// TODO Auto-generated method stub
				Employee employee = new Employee();
				int empId = resultSet.getInt(1);
				employee.setEmpId(empId);
				employee.setEmpName(resultSet.getString(2));
				employee.setSalary(resultSet.getInt(3));
				return employee;
			}
		});

		return employees;
	}

	@Override
	public List<Employee> findAllEmployeesBySalary(int salary) {
		// TODO Auto-generated method stub
		List<Employee> employees = new ArrayList<>();
		String FIND_BY_SALARY = "select * from employee where salary=?";
		employees = jdbcTemplate.query(FIND_BY_SALARY, (resultSet, i) -> {
			Employee employee = new Employee();
			int empId = resultSet.getInt(1);
			employee.setEmpId(empId);
			employee.setEmpName(resultSet.getString(2));
			employee.setSalary(resultSet.getInt(3));
			return employee;
		}, salary);

		return employees;
	}

}
