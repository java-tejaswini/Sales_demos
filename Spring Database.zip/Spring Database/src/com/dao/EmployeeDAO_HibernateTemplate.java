package com.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.pojo.Employee;

@Repository(value = "dao_hib")
public class EmployeeDAO_HibernateTemplate implements EmployeeDAO {

	@Autowired
	HibernateTemplate template;

	@Override
	public Employee findEmployeeById(int empId) {
		// TODO Auto-generated method stub
		return template.get(Employee.class, empId);
	}

	@Override
	@Transactional
	public int addEmployee(Employee employee) {
		// TODO Auto-generated method stub

		template.save(employee);
		return 1;

	}

	@Override
	public boolean updateEmployeeSalary(int empId, int salary) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<Employee> findAllEmployees() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Employee> findAllEmployeesBySalary(int salary) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int deleteEmployeeById(int empId) {
		// TODO Auto-generated method stub
		return 0;
	}

}
