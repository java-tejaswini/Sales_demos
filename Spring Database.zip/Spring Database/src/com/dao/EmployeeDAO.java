package com.dao;

import java.util.List;

import com.pojo.Employee;

public interface EmployeeDAO {
	
	int addEmployee(Employee employee);
	boolean updateEmployeeSalary(int empId, int salary);
	Employee findEmployeeById(int empId);
	List<Employee>findAllEmployees();
	List<Employee>findAllEmployeesBySalary(int salary);
	int deleteEmployeeById(int empId);

}
