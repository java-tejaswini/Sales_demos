package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.pojo.Employee;

@Repository(value = "dao_source")
public class EmployeeDAOImpl_DataSource implements EmployeeDAO {
	@Autowired
	DataSource dataSource;

	@Override
	public int addEmployee(Employee employee) {
		// TODO Auto-generated method stub
		int rows_added=0;
		String ADD="insert into employee values(?,?,?)";
		
		try {
			Connection connection=dataSource.getConnection();
			PreparedStatement ps=connection.prepareStatement(ADD);
			ps.setInt(1, employee.getEmpId());
			ps.setString(2, employee.getEmpName());
			ps.setInt(3, employee.getSalary());
			rows_added=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return rows_added;
	}

	@Override
	public boolean updateEmployeeSalary(int empId, int salary) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Employee findEmployeeById(int empId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Employee> findAllEmployees() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Employee> findAllEmployeesBySalary(int salary) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int deleteEmployeeById(int empId) {
		// TODO Auto-generated method stub
		return 0;
	}

}
