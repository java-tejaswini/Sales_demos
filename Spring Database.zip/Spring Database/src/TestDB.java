import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.dao.EmployeeDAO;
import com.pojo.Employee;

public class TestDB {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext context = new ClassPathXmlApplicationContext("connection.xml");
		EmployeeDAO dao = (EmployeeDAO) context.getBean("dao_hib");
		int added=dao.addEmployee(new Employee(114, "ABC34", 20000));
		if(added==1) {
			System.out.println("ADDED");
		}
		else {
			System.out.println("Cann't add");
		}

//		if (dao.updateEmployeeSalary(78, 1000)) {
//			System.out.println("Record updated");
//		} else {
//			System.out.println("No Record");
//		}
//
//		if (dao.deleteEmployeeById(1) == 1) {
//			System.out.println("Record deleted");
//		} else {
//			System.out.println("No Record");
//		}
//		
		Employee employee=dao.findEmployeeById(78);
		if(employee!=null) {
			System.out.println(employee);
		}
		else {
			System.out.println("No Record");
		}
//		System.out.println("All emp details");
//		dao.findAllEmployees().forEach(System.out::println);
//		
//		System.out.println("All emp details for salary");
//		dao.findAllEmployeesBySalary(1000).forEach(System.out::println);
		
		
	}

}
