package com.scope;

import org.springframework.context.ApplicationContext;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.life_cycle.Address;

public class TestScope {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ApplicationContext context = new ClassPathXmlApplicationContext("scope.xml");
		Address address = (Address) context.getBean("address");
		System.out.println("initial address:-" + address);

		address.setCity("new city");

		System.out.println("after changing city name:-" + address);

		Address address1 = (Address) context.getBean("address");
		System.out.println("2nd request address:-" + address1);

		context.getBean("address");
		context.getBean("address");
		context.getBean("address");

	}
}
