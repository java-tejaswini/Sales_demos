package com.data;

import java.util.List;
import java.util.Map;

public class Company_map {

	private Map<String, Employee> employees;

	public Company_map() {
		// TODO Auto-generated constructor stub
	}

	public Map<String, Employee> getEmployees() {
		return employees;
	}

	public void setEmployees(Map<String, Employee> employees) {
		this.employees = employees;
	}
	
	public void display() {
		employees.forEach((key,value)->
		     {System.out.println(key+":"+value.getEmpId());});
	}
	

}
