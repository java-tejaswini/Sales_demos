package com.data;

import java.util.List;

public class Company {

	private int compId;
	private String compName;
	private List<Employee> employees;

	public Company() {
		// TODO Auto-generated constructor stub
	}

	public Company(int compId, String compName, List<Employee> employees) {
		super();
		this.compId = compId;
		this.compName = compName;
		this.employees = employees;
	}
	
	public void display() {
		System.out.println("comp name:" + compName + "Company Id : " + compId);
		employees.forEach(System.out::println);

	}


	public int getCompId() {
		return compId;
	}

	public void setCompId(int compId) {
		this.compId = compId;
	}

	public String getCompName() {
		return compName;
	}

	public void setCompName(String compName) {
		this.compName = compName;
	}

	public List<Employee> getEmployees() {
		return employees;
	}

	public void setEmployees(List<Employee> employees) {
		this.employees = employees;
	}

	
}
