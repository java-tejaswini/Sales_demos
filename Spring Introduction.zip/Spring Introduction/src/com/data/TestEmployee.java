package com.data;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestEmployee {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
		Employee employee = (Employee) context.getBean("employee");// =new Employee();
		employee.display();
		System.out.println(employee);

		Employee emp_const = (Employee) context.getBean("emp_const");// =new Employee();
		emp_const.display();
		System.out.println(emp_const);

		Employee emp_name = (Employee) context.getBean("emp_name");// =new Employee();
		emp_const.display();
		System.out.println(emp_const);

//		Address address = (Address) context.getBean("address1");
//		System.out.println(address);

		Company company = (Company) context.getBean("com");
		company.display();
		Company_map company_map = (Company_map) context.getBean("com_map");
		company_map.display();

		
	}

}
