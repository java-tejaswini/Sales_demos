package com.life_cycle;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestLife_Cycle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		AbstractApplicationContext context = new ClassPathXmlApplicationContext("life_cycle.xml");
		Address address = (Address) context.getBean("address");
		System.out.println("initial address:-" + address);
		System.out.println("com address=" + address.getComplete_address());

		context.registerShutdownHook();

	}
}
