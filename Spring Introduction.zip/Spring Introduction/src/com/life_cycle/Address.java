package com.life_cycle;

import org.springframework.beans.factory.InitializingBean;

public class Address implements InitializingBean {
	private String city;
	private String pincode;
	private String complete_address;

	public Address() {
		// TODO Auto-generated constructor stub
		System.out.println("constructor called");
	}

	public Address(String city, String pincode) {
		super();
		this.city = city;
		this.pincode = pincode;
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		// TODO Auto-generated method stub
		System.out.println("Initializing bean afterproperty set method");
		if (city.equals("Mumbai")) {
			city = "Mumbai, MH";
		}

	}

	public void myDestroy() {
		System.out.println("custom destroy method");
		complete_address=null;
	}
	
	
	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		System.out.println("value of city set");
		this.city = city;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		System.out.println("value of pincode set");
		this.pincode = pincode;
	}

	public String getComplete_address() {
		return complete_address;
	}

	public void setComplete_address(String complete_address) {
		this.complete_address = complete_address;
	}

	@Override
	public String toString() {
		return "Address [city=" + city + ", pincode=" + pincode + "]";
	}

	public void myInit() {
		System.out.println("custom init method invoked");
		complete_address = city.concat(" ").concat(pincode);
	}

}
