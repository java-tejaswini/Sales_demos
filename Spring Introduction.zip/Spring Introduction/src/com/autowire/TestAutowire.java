package com.autowire;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.data.Employee;

public class TestAutowire {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ApplicationContext context = new ClassPathXmlApplicationContext("autowire.xml");
		Employee employee = (Employee) context.getBean("employee");// =new Employee();
		employee.display();
		System.out.println(employee);

	}

}
