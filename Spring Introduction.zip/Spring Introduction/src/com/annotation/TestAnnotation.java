package com.annotation;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestAnnotation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext context =
				new AnnotationConfigApplicationContext(MyConfig.class); //new ClassPathXmlApplicationContext("annotation.xml");
		Address address = (Address) context.getBean("address");
		System.out.println("initial address:-" + address);

		Employee employee = (Employee) context.getBean("employee");
		System.out.println(employee);

//		Employee myEmp = (Employee) context.getBean("myEmployee1");
//		System.out.println(myEmp);

	}

}
