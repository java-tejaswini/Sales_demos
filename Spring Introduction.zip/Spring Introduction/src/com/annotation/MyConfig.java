package com.annotation;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages = "com")
public class MyConfig {

	@Bean(value = "employee")
	public Employee myEmployee() {
		Employee employee = new Employee();
		employee.setEmpId(100);
		employee.setEmpName("ABCD");
		return employee;
	}

	@Bean // (value = "address1")
	public Address address() {
		return new Address("Banglore", "809000");
	}
	
//	@Bean(value = "employee")
//	public Employee myEmployee1() {
//		Employee employee = new Employee();
//		employee.setEmpId(200);
//		employee.setEmpName("ABCD");
//		return employee;
//	}

}
